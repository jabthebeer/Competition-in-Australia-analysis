README NOTES FOR FIGURES

1. Description of Figure Files

For each figure in the paper there is a .m script in the folder "figures_replication" as described below which runs code and/or loads previously saved results to produce a .png file with the relevant figure in the subfolder "figures".

Figure 1: Markup Distribution and Misallocation in Benchmark Model

* created with figure1.m in this archive
* loads data/benchmark_calibration.mat which has saved results for each Mu in (1.05:0.01:1.45)
* see below for more details on the contents of benchmark_calibration.mat
* saves figures/Figure1.png

Figure 2: Equilibrium and Planner Allocations

* created with figure2.m in this archive
* uses model code: findequilibrium.m; firmfoc.m; upsilon.m; transition.mod; etc included in this archive
* solves model for calibration corresponding to Mu = 1.15  
* compares equilibrium q(z),l(z) to planner's q*(z),l*(z)
* saves figures/Figure2.png

Figure 3: Welfare Gains from Alternative Policies

* created with figure3.m in this archive
* loads data/benchmark_calibration.mat which has saved results for each Mu in (1.05:0.01:1.45)
* loops over saved results for 4 policy scenarios 
* loads data/benchmark_[scenario].mat with saved results for each of 4 policy scenarios
("efficient","uniform_subsidy","size_depdenent_subsidy","entry_subsidy") 
* see below for more detail on the contents of benchmark_[scenario].mat
* saves figures/Figure3.png

Figure 4: Optimal Entry Subsidy, Mu = 1.15

* created with figure4.m in this archive
* uses model code: findequilibrium.m; firmfoc.m; upsilon.m; transition.mod; etc included in this archive
* solves model for calibration corresponding to Mu = 1.15 for each entry subsidy chi_e in (0.1:0.01:0.7) 
* note: this grid is just for illustrative purposes, optimal entry calculations reported in tables etc find optimal chi_e by golden search
* saves figures/Figure4.png

Figure 5:  Effect of Entry Subsidy on Markups
 
* created with figure5.m in this archive 
* uses model code: findequilibrium.m; firmfoc.m; upsilon.m; transition.mod; etc included in this archive
* solves model for calibration corresponding to Mu = 1.15 and solves model for entry subsidy chi_e = 3 which approximately triples N
* compares equilibrium markups mu(z) and employment l(z)  
* saves figures/Figure5.png

Figure 6:  Aggregate Markup with Translog Demand
 
* created with figure6.m in this archive
* uses ExpInt.m to callculate values of the Exponential Integral, included in this archive    
* left panel plots closed-form solution for aggregate markup Mu, equation (79) in the text, as a function of sigma*N for various levels of xi   
* right panel plots locus of xi and sigma*N such that cutoff condition from equation (78) in the text holds exactly
* saves figures/Figure6.png 

Figure A1: Cost-Weighted vs. Sales-Weighted Average Markups, Compustat

* created with figureA1.m in this archive
* loads spreadsheet data/sales_and_cost_weighted_markups_compustat.csv which summarizes sales and cost weighted average markups from Compustat data, as discussed in Appendix A.
* saves figures/FigureA1.png 


Figure B1: Cost-Weighted vs. Sales-Weighted Average Markups, Compustat

* created with figureB1.m in this archive
* loads spreadsheet data/sales_and_cost_weighted_markups_census.csv which summarizes sales and cost weighted average markups from Census data, as discussed in Appendix B.
* saves figures/FigureB1.png

2. Contents of Saved Results

2.1 Contents of saved_results/benchmark_calibration.mat

	Calibrated_parameters       41x1             3413496  cell                
  	Data_moments                41x1                6232  cell                
  	Markuptargets               41x1                 328  double              
  	Model_markups               41x1             1644264  cell                
  	Model_misallocation         41x1                4592  cell                
  	Model_misallocation_va      41x1                4592  cell                
  	Model_moments               41x1                6232  cell                
  	Model_weights               41x1             1644264  cell                


* Markuptargets is a 41-by-1 vector with Mu grid (1.05:0.01:1.45)
* for each m=1:41 we have a entries such as (illustrated for Mu=1.15, m=11)

	Calibrated_parameters{11}

        xi: 6.8343
     sigma: 10.8403
       phi: 0.4265
      epsi: 1.7561
      beta: 0.9600
    varphi: 0.0400
     delta: 0.0600
         r: 0.0417
        nu: 1
     alpha: 0.3333
     theta: 0.5000
       xie: 0
       xis: 0
      taus: 0
         w: [5000×1 double] [quadrature weights]
         z: [5000×1 double]	[quadrature nodes]
         F: 0.6712
       psi: 35.2538


2.2 Contents of saved_results/benchmark_[scenario].mat for each of 4 policy scenarios 

	Results      41x1             936112  cell   

* for each m=1:41 we have a entries such as (illustrated for Mu=1.15, m=11, scenario=efficient)

	Results{11}

	  welfare: 8.6911
           timepaths: [1×1 struct]   
    old_steady_state: [13×1 double]
    new_steady_state: [13×1 double]

which lists the (scalar) welfare result for that Mu and policy scenario, a structure which records the time paths between the old and new steady states for key variables

	Results{11}.timepaths

     Yt: [252×1 double]
     Ct: [252×1 double]
     Bt: [252×1 double] [materials, X in the paper's notation]
    Lpt: [252×1 double] [labor used in production]  
     Kt: [252×1 double]
     Nt: [252×1 double]
     Wt: [252×1 double]
     Rt: [252×1 double]
     Zt: [252×1 double]
    Mut: [252×1 double]

along with vectors of new and old steady state values




















*   loads "benchmark_calibration.mat" with  saved results 
   
   for each Mu in [1.05:0.01:1.45]

%   loads "benchmark_[scenario].mat" with saved results for each of 4 scenarios
%           scenario1 = efficient
%           scenario2 = uniform_subsidy
%           scenario3 = size_dependent_subsidy
%           scenario4 = entry_subsidy



* figure2.m 




2. Description of Data Files




1. Description of Saved Results

1.1 Folder titled "saved_results" contains .mat files with saved results that are called by .m scripts to produce figures as described below

1.2 These .mat files are as follows:

	* "benchmark_calibration.mat" records calibrated parameters, data moments [calibration targets], model moments, model markup distribution, model misallocation results etc for each aggregate markup Mu on the grid (1.05:0.01:1.45)

	* the results are stored as cells with each cell entry corresponding to a value of Mu




	* benchmark_efficient.mat
	* benchmark_uniform.mat
	* benchmark_size_dependent.mat
	* benchmark_entry.mat



Results{1}

ans = 

  struct with fields:

             welfare: 1.3371
           timepaths: [1×1 struct]
    old_steady_state: [13×1 double]
    new_steady_state: [13×1 double]


    Results{1}.timepaths

ans = 

  struct with fields:

     Yt: [252×1 double]
     Ct: [252×1 double]
     Bt: [252×1 double]
    Lpt: [252×1 double]
     Kt: [252×1 double]
     Nt: [252×1 double]
     Wt: [252×1 double]
     Rt: [252×1 double]
     Zt: [252×1 double]
    Mut: [252×1 double]


Figure 1.


load benchmark_calibration.mat

  Calibrated_parameters       41x1             3413496  cell                
  Data_moments                41x1                6232  cell                
  Markuptargets                1x41                328  double              
  Model_markups               41x1             1644264  cell                
  Model_misallocation         41x1                4592  cell                
  Model_misallocation_va      41x1                4592  cell                
  Model_moments               41x1                6232  cell                
  Model_weights               41x1             1644264  cell                


for each Markuptarget mm=1:41 we have a cell entry with markup distribution etc. 

misallocation_va(mm) = Model_misallocation_va{mm}; % value added, M=1
