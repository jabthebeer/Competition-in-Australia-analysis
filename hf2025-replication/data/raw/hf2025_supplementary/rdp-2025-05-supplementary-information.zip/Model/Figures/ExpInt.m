%%% generalized exponential integral using upper incomplete gamma

function E_nx = ExpInt(n,x)

E_nx = (x.^(n-1)).*igamma(1-n,x);