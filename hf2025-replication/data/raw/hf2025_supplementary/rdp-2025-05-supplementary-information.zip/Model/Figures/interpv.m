function [y, yx, yxx] = interpv(x, i)

global cfun fspace

y      = funeval(cfun(:, i), fspace, x);
yx     = funeval(cfun(:, i), fspace, x, 1);
yxx    = funeval(cfun(:, i), fspace, x, 2);

