%
% Status : main Dynare file
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

tic0 = tic;
% Define global variables.
global M_ options_ oo_ estim_params_ bayestopt_ dataset_ dataset_info estimation_info ys0_ ex0_
options_ = [];
M_.fname = 'transition';
M_.dynare_version = '5.1';
oo_.dynare_version = '5.1';
options_.dynare_version = '5.1';
%
% Some global variables initialization
%
global_initialization;
M_.exo_names = {};
M_.exo_names_tex = {};
M_.exo_names_long = {};
M_.endo_names = cell(13,1);
M_.endo_names_tex = cell(13,1);
M_.endo_names_long = cell(13,1);
M_.endo_names(1) = {'Yt'};
M_.endo_names_tex(1) = {'Yt'};
M_.endo_names_long(1) = {'Yt'};
M_.endo_names(2) = {'Ct'};
M_.endo_names_tex(2) = {'Ct'};
M_.endo_names_long(2) = {'Ct'};
M_.endo_names(3) = {'Bt'};
M_.endo_names_tex(3) = {'Bt'};
M_.endo_names_long(3) = {'Bt'};
M_.endo_names(4) = {'Lpt'};
M_.endo_names_tex(4) = {'Lpt'};
M_.endo_names_long(4) = {'Lpt'};
M_.endo_names(5) = {'Kt'};
M_.endo_names_tex(5) = {'Kt'};
M_.endo_names_long(5) = {'Kt'};
M_.endo_names(6) = {'Nt'};
M_.endo_names_tex(6) = {'Nt'};
M_.endo_names_long(6) = {'Nt'};
M_.endo_names(7) = {'Wt'};
M_.endo_names_tex(7) = {'Wt'};
M_.endo_names_long(7) = {'Wt'};
M_.endo_names(8) = {'Rt'};
M_.endo_names_tex(8) = {'Rt'};
M_.endo_names_long(8) = {'Rt'};
M_.endo_names(9) = {'Qt'};
M_.endo_names_tex(9) = {'Qt'};
M_.endo_names_long(9) = {'Qt'};
M_.endo_names(10) = {'Zt'};
M_.endo_names_tex(10) = {'Zt'};
M_.endo_names_long(10) = {'Zt'};
M_.endo_names(11) = {'Gt'};
M_.endo_names_tex(11) = {'Gt'};
M_.endo_names_long(11) = {'Gt'};
M_.endo_names(12) = {'Ot'};
M_.endo_names_tex(12) = {'Ot'};
M_.endo_names_long(12) = {'Ot'};
M_.endo_names(13) = {'Mut'};
M_.endo_names_tex(13) = {'Mut'};
M_.endo_names_long(13) = {'Mut'};
M_.endo_partitions = struct();
M_.param_names = cell(9,1);
M_.param_names_tex = cell(9,1);
M_.param_names_long = cell(9,1);
M_.param_names(1) = {'beta'};
M_.param_names_tex(1) = {'beta'};
M_.param_names_long(1) = {'beta'};
M_.param_names(2) = {'varphi'};
M_.param_names_tex(2) = {'varphi'};
M_.param_names_long(2) = {'varphi'};
M_.param_names(3) = {'delta'};
M_.param_names_tex(3) = {'delta'};
M_.param_names_long(3) = {'delta'};
M_.param_names(4) = {'psi'};
M_.param_names_tex(4) = {'psi'};
M_.param_names_long(4) = {'psi'};
M_.param_names(5) = {'F'};
M_.param_names_tex(5) = {'F'};
M_.param_names_long(5) = {'F'};
M_.param_names(6) = {'nu'};
M_.param_names_tex(6) = {'nu'};
M_.param_names_long(6) = {'nu'};
M_.param_names(7) = {'alpha'};
M_.param_names_tex(7) = {'alpha'};
M_.param_names_long(7) = {'alpha'};
M_.param_names(8) = {'theta'};
M_.param_names_tex(8) = {'theta'};
M_.param_names_long(8) = {'theta'};
M_.param_names(9) = {'phi'};
M_.param_names_tex(9) = {'phi'};
M_.param_names_long(9) = {'phi'};
M_.param_partitions = struct();
M_.exo_det_nbr = 0;
M_.exo_nbr = 0;
M_.endo_nbr = 13;
M_.param_nbr = 9;
M_.orig_endo_nbr = 13;
M_.aux_vars = [];
M_ = setup_solvers(M_);
M_.Sigma_e = zeros(0, 0);
M_.Correlation_matrix = eye(0, 0);
M_.H = 0;
M_.Correlation_matrix_ME = 1;
M_.sigma_e_is_diagonal = true;
M_.det_shocks = [];
M_.surprise_shocks = [];
M_.heteroskedastic_shocks.Qvalue_orig = [];
M_.heteroskedastic_shocks.Qscale_orig = [];
options_.linear = false;
options_.block = false;
options_.bytecode = false;
options_.use_dll = false;
M_.orig_eq_nbr = 13;
M_.eq_nbr = 13;
M_.ramsey_eq_nbr = 0;
M_.set_auxiliary_variables = exist(['./+' M_.fname '/set_auxiliary_variables.m'], 'file') == 2;
M_.epilogue_names = {};
M_.epilogue_var_list_ = {};
M_.orig_maximum_endo_lag = 1;
M_.orig_maximum_endo_lead = 1;
M_.orig_maximum_exo_lag = 0;
M_.orig_maximum_exo_lead = 0;
M_.orig_maximum_exo_det_lag = 0;
M_.orig_maximum_exo_det_lead = 0;
M_.orig_maximum_lag = 1;
M_.orig_maximum_lead = 1;
M_.orig_maximum_lag_with_diffs_expanded = 1;
M_.lead_lag_incidence = [
 0 3 0;
 0 4 16;
 0 5 0;
 0 6 0;
 1 7 0;
 2 8 0;
 0 9 0;
 0 10 17;
 0 11 18;
 0 12 0;
 0 13 0;
 0 14 0;
 0 15 0;]';
M_.nstatic = 8;
M_.nfwrd   = 3;
M_.npred   = 2;
M_.nboth   = 0;
M_.nsfwrd   = 3;
M_.nspred   = 2;
M_.ndynamic   = 5;
M_.dynamic_tmp_nbr = [16; 6; 0; 0; ];
M_.model_local_variables_dynamic_tt_idxs = {
};
M_.equations_tags = {
  1 , 'name' , '1' ;
  2 , 'name' , '2' ;
  3 , 'name' , 'Qt' ;
  4 , 'name' , 'Wt' ;
  5 , 'name' , 'Ot' ;
  6 , 'name' , 'Yt' ;
  7 , 'name' , '7' ;
  8 , 'name' , 'Rt' ;
  9 , 'name' , '9' ;
  10 , 'name' , 'Zt' ;
  11 , 'name' , 'Gt' ;
  12 , 'name' , 'Mut' ;
  13 , 'name' , '13' ;
};
M_.mapping.Yt.eqidx = [3 6 7 8 9 ];
M_.mapping.Ct.eqidx = [1 2 3 4 6 ];
M_.mapping.Bt.eqidx = [6 9 ];
M_.mapping.Lpt.eqidx = [4 7 ];
M_.mapping.Kt.eqidx = [6 8 ];
M_.mapping.Nt.eqidx = [3 4 10 11 12 ];
M_.mapping.Wt.eqidx = [2 4 5 7 8 ];
M_.mapping.Rt.eqidx = [1 5 7 8 ];
M_.mapping.Qt.eqidx = [2 3 ];
M_.mapping.Zt.eqidx = [10 13 ];
M_.mapping.Gt.eqidx = [3 11 ];
M_.mapping.Ot.eqidx = [5 7 8 9 13 ];
M_.mapping.Mut.eqidx = [7 8 9 12 13 ];
M_.static_and_dynamic_models_differ = false;
M_.has_external_function = true;
M_.state_var = [5 6 ];
M_.exo_names_orig_ord = [1:0];
M_.maximum_lag = 1;
M_.maximum_lead = 1;
M_.maximum_endo_lag = 1;
M_.maximum_endo_lead = 1;
oo_.steady_state = zeros(13, 1);
M_.maximum_exo_lag = 0;
M_.maximum_exo_lead = 0;
oo_.exo_steady_state = zeros(0, 1);
M_.params = NaN(9, 1);
M_.endo_trends = struct('deflator', cell(13, 1), 'log_deflator', cell(13, 1), 'growth_factor', cell(13, 1), 'log_growth_factor', cell(13, 1));
M_.NNZDerivatives = [52; -1; -1; ];
M_.static_tmp_nbr = [16; 6; 0; 0; ];
M_.model_local_variables_static_tt_idxs = {
};
load xpar;
M_.params(1) = xpar(1);
beta = M_.params(1);
M_.params(2) = xpar(2);
varphi = M_.params(2);
M_.params(3) = xpar(3);
delta = M_.params(3);
M_.params(4) = xpar(4);
psi = M_.params(4);
M_.params(5) = xpar(5);
F = M_.params(5);
M_.params(6) = xpar(6);
nu = M_.params(6);
M_.params(7) = xpar(7);
alpha = M_.params(7);
M_.params(8) = xpar(8);
theta = M_.params(8);
M_.params(9) = xpar(9);
phi = M_.params(9);
load x1_ss;
load x2_ss;
%
% INITVAL instructions
%
options_.initval_file = false;
oo_.steady_state(5) = x1_ss(1);
oo_.steady_state(6) = x1_ss(2);
if M_.exo_nbr > 0
	oo_.exo_simul = ones(M_.maximum_lag,1)*oo_.exo_steady_state';
end
if M_.exo_det_nbr > 0
	oo_.exo_det_simul = ones(M_.maximum_lag,1)*oo_.exo_det_steady_state';
end
%
% ENDVAL instructions
%
ys0_= oo_.steady_state;
ex0_ = oo_.exo_steady_state;
oo_.steady_state(1) = x2_ss(1);
oo_.steady_state(2) = x2_ss(2);
oo_.steady_state(3) = x2_ss(3);
oo_.steady_state(4) = x2_ss(4);
oo_.steady_state(5) = x2_ss(5);
oo_.steady_state(6) = x2_ss(6);
oo_.steady_state(7) = x2_ss(7);
oo_.steady_state(8) = x2_ss(8);
oo_.steady_state(9) = x2_ss(9);
oo_.steady_state(10) = x2_ss(10);
oo_.steady_state(11) = x2_ss(11);
oo_.steady_state(12) = x2_ss(12);
oo_.steady_state(13) = x2_ss(13);
resid;
steady;
options_.periods = 500;
perfect_foresight_setup;
options_.dynatol.f = 1e-10;
options_.dynatol.x = 1e-10;
perfect_foresight_solver;


oo_.time = toc(tic0);
disp(['Total computing time : ' dynsec2hms(oo_.time) ]);
if ~exist([M_.dname filesep 'Output'],'dir')
    mkdir(M_.dname,'Output');
end
save([M_.dname filesep 'Output' filesep 'transition_results.mat'], 'oo_', 'M_', 'options_');
if exist('estim_params_', 'var') == 1
  save([M_.dname filesep 'Output' filesep 'transition_results.mat'], 'estim_params_', '-append');
end
if exist('bayestopt_', 'var') == 1
  save([M_.dname filesep 'Output' filesep 'transition_results.mat'], 'bayestopt_', '-append');
end
if exist('dataset_', 'var') == 1
  save([M_.dname filesep 'Output' filesep 'transition_results.mat'], 'dataset_', '-append');
end
if exist('estimation_info', 'var') == 1
  save([M_.dname filesep 'Output' filesep 'transition_results.mat'], 'estimation_info', '-append');
end
if exist('dataset_info', 'var') == 1
  save([M_.dname filesep 'Output' filesep 'transition_results.mat'], 'dataset_info', '-append');
end
if exist('oo_recursive_', 'var') == 1
  save([M_.dname filesep 'Output' filesep 'transition_results.mat'], 'oo_recursive_', '-append');
end
if ~isempty(lastwarn)
  disp('Note: warning(s) encountered in MATLAB/Octave code')
end
