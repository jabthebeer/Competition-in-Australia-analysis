function T = static_g1_tt(T, y, x, params)
% function T = static_g1_tt(T, y, x, params)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T         [#temp variables by 1]  double   vector of temporary terms to be filled by function
%   y         [M_.endo_nbr by 1]      double   vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1]       double   vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1]     double   vector of parameter values in declaration order
%
% Output:
%   T         [#temp variables by 1]  double   vector of temporary terms
%

assert(length(T) >= 22);

T = transition.static_resid_tt(T, y, x, params);

T(17) = getPowerDeriv(y(4)+params(5)*(y(6)-y(6)*(1-params(2))),params(6),1);
T(18) = T(2)*1/(1-params(7))*getPowerDeriv(y(7)/(1-params(7)),1-params(7),1);
T(19) = getPowerDeriv(T(4),1-params(8),1);
T(20) = getPowerDeriv(T(5),1/(1-params(8)),1);
T(21) = getPowerDeriv(T(4)/y(12),1-params(8),1);
T(22) = T(3)*1/params(7)*getPowerDeriv(y(8)/params(7),params(7),1);

end
