MODEL

This document provides details on how to reproduce the model-generated numbers reported in the tables in the paper. 

All model output is generated in MATLAB. In addition to built-in Matlab programs, the code uses the following external software: 

1. CompEcon Toolbox, available for download at https://pfackler.wordpress.ncsu.edu/compecon-download/ 

The user should first install the CompEcon Toolbox and compile the .mex files. The user should use the demo files to verify correct compilation. 

2. Dynare, available at https://www.dynare.org/

The user should first install Dynare and add the corresponding folder to the Matlab path. 

We used version 4.6.1

We tested the codes on a 2017 iMac Pro, 3 GHz 10-Core Intel Xeon W and 128 GB of memory. Most of the experiments in Tables 1 - 4 run under 1 minute, with the exception of Table 4c (entry subsidy) which runs approximately 5 minutes. The experiments in Table 5-7 are based on Monte-Carlo simulations and can run for as long as 12 hours depending on the specification and number of sectors used in simulation (we used 100,000 for the numbers reported in the paper).

*************


Table 1, Panels A and B

run /Model/Tables/Benchmark/start.m after:

i)   changing line 7 of start.m to report = 'T1'; 

ii)  changing line 8 of start.m to, say, markup = '1.15' for a desired aggregate markup target of 1.15 (admissible markup targets are 1.05, 1.15, 1.25, 1.35);


Table 3

run /Model/Tables/Benchmark/start.m after:

i)   changing line 7 of start.m to report = 'T3'

ii)  changing line 8 of start.m to, say, markup = '1.15' for a desired aggregate markup target of 1.15 (admissible markup targets are 1.05, 1.15, 1.25, 1.35); 


Table 4

run /Model/Tables/Benchmark/start.m after: 

i)   changing line 7 of start.m to report = 'T4';

ii)  changing line 8 of start.m to, say, markup = '1.15' for a desired aggregate markup target of 1.15 (admissible markup targets are 1.05, 1.15, 1.25, 1.35); 

iii) selecting the desired experiment. I particular, to reproduce  

	a) row "efficient": change line 9 of start.m to experiment = 'efficient';
	b) row "uniform subsidy": change of start.m line 9 to experiment = 'uniform';
	c) row "size-dependent subsidy": change line 9 of start.m to experiment = 'sizedep';
	d) row "entry subsidy": change line 9 of start.m to experiment = 'entry';


Table 5

run /Model/Tables/Cournot/start.m after:

i)   changing line 7 of start.m to report = 'T5'; 

ii)  changing line 8 of start.m to, say, markup = '1.15' for a desired aggregate markup target of 1.15 (admissible markup targets are 1.05, 1.15, 1.25, 1.35);


Table 6

run /Model/Tables/Cournot/start.m after:

i)   changing line 7 of start.m to report = 'T6'

ii)  changing line 8 of start.m to, say, markup = '1.15' for a desired aggregate markup target of 1.15 (admissible markup targets are 1.05, 1.15, 1.25, 1.35); 


Table 7

run /Model/Tables/Cournot/start.m after: 

i)   changing line 7 of start.m to report = 'T7';

ii)  changing line 8 of start.m to, say, markup = '1.15' for a desired aggregate markup target of 1.15 (admissible markup targets are 1.05, 1.15, 1.25, 1.35); 

iii) selecting the desired experiment. I particular, to reproduce  

	a) row "efficient": change line 9 of start.m to experiment = 'efficient';
	b) row "uniform subsidy": change of start.m line 9 to experiment = 'uniform';
	c) row "size-dependent subsidy": change line 9 of start.m to experiment = 'sizedep';
	d) row "entry subsidy": change line 9 of start.m to experiment = 'entry';
