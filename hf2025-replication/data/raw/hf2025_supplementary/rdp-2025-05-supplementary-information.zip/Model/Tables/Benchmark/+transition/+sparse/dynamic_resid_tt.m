function [T_order, T] = dynamic_resid_tt(y, x, params, steady_state, T_order, T)
if T_order >= 0
    return
end
T_order = 0;
if size(T, 1) < 16
    T = [T; NaN(16 - size(T, 1), 1)];
end
T(1) = (y(17)+params(5)*(y(19)-y(6)*(1-params(2))))^params(6);
T(2) = (y(21)/params(7))^params(7);
T(3) = (y(20)/(1-params(7)))^(1-params(7));
T(4) = T(2)*T(3);
T(5) = params(9)*T(4)^(1-params(8))+1-params(9);
T(6) = params(9)*(1-params(7))/y(26);
T(7) = (T(4)/y(25))^(1-params(8));
T(8) = params(9)*params(7)/y(26);
T(9) = (1/y(25))^(1-params(8));
T(10) = (1-params(9))/y(26)*T(9);
[TEF_0, TEFD_0, TEFDD_0] = interpv(y(6),1);
T(11) = TEF_0;
[TEF_1, TEFD_1, TEFDD_1] = interpv(y(6),2);
T(12) = TEF_1;
[TEF_2, TEFD_2, TEFDD_2] = interpv(y(6),3);
T(13) = TEF_2;
T(14) = TEFD_0(1);
T(15) = TEFD_1(1);
T(16) = TEFD_2(1);
end
