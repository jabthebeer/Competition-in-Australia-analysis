function g1 = static_g1(T, y, x, params, T_flag)
% function g1 = static_g1(T, y, x, params, T_flag)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T         [#temp variables by 1]  double   vector of temporary terms to be filled by function
%   y         [M_.endo_nbr by 1]      double   vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1]       double   vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1]     double   vector of parameter values in declaration order
%                                              to evaluate the model
%   T_flag    boolean                 boolean  flag saying whether or not to calculate temporary terms
%
% Output:
%   g1
%

if T_flag
    T = transition.static_g1_tt(T, y, x, params);
end
g1 = zeros(13, 13);
g1(1,8)=(-params(1));
g1(2,7)=params(5);
g1(2,9)=(-params(1));
g1(3,1)=(-(y(11)*1/y(6)));
g1(3,6)=(-(y(11)*(-y(1))/(y(6)*y(6))));
g1(3,9)=1-params(1)*(1-params(2));
g1(3,11)=(-(y(1)/y(6)));
g1(4,2)=(-(params(4)*T(1)));
g1(4,4)=(-(y(2)*params(4)*T(17)));
g1(4,6)=(-(y(2)*params(4)*T(17)*params(5)*(1-(1-params(2)))));
g1(4,7)=1;
g1(5,7)=(-(params(9)*T(18)*T(19)*T(20)));
g1(5,8)=(-(T(20)*params(9)*T(19)*T(22)));
g1(5,12)=1;
g1(6,1)=1;
g1(6,2)=(-1);
g1(6,3)=(-1);
g1(6,5)=(-(1-(1-params(3))));
g1(7,1)=(-(T(6)*T(7)/y(4)));
g1(7,4)=(-((-(y(1)*T(6)*T(7)))/(y(4)*y(4))));
g1(7,7)=1-y(1)*T(6)*T(18)/y(12)*T(21)/y(4);
g1(7,8)=(-(y(1)*T(6)*T(21)*T(22)/y(12)/y(4)));
g1(7,12)=(-(y(1)*T(6)*T(21)*(-T(4))/(y(12)*y(12))/y(4)));
g1(7,13)=(-(y(1)*T(7)*(-(params(9)*(1-params(7))))/(y(13)*y(13))/y(4)));
g1(8,1)=(-(T(7)*T(8)/y(5)));
g1(8,5)=(-((-(y(1)*T(7)*T(8)))/(y(5)*y(5))));
g1(8,7)=(-(y(1)*T(8)*T(18)/y(12)*T(21)/y(5)));
g1(8,8)=1-y(1)*T(8)*T(21)*T(22)/y(12)/y(5);
g1(8,12)=(-(y(1)*T(8)*T(21)*(-T(4))/(y(12)*y(12))/y(5)));
g1(8,13)=(-(y(1)*T(7)*(-(params(9)*params(7)))/(y(13)*y(13))/y(5)));
g1(9,1)=(-(T(10)/y(3)));
g1(9,3)=(-((-(y(1)*T(10)))/(y(3)*y(3))));
g1(9,12)=(-(y(1)*(1-params(9))/y(13)*(-1)/(y(12)*y(12))*getPowerDeriv(1/y(12),1-params(8),1)/y(3)));
g1(9,13)=(-(y(1)*T(9)*(-(1-params(9)))/(y(13)*y(13))/y(3)));
g1(10,6)=(-T(14));
g1(10,10)=1;
g1(11,6)=(-T(15));
g1(11,11)=1;
g1(12,6)=(-T(16));
g1(12,13)=1;
g1(13,10)=(-(1/y(13)));
g1(13,12)=1;
g1(13,13)=(-((-y(10))/(y(13)*y(13))));

end
