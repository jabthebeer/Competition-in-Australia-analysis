function [T_order, T] = static_g1_tt(y, x, params, T_order, T)
if T_order >= 1
    return
end
[T_order, T] = transition.sparse.static_resid_tt(y, x, params, T_order, T);
T_order = 1;
if size(T, 1) < 22
    T = [T; NaN(22 - size(T, 1), 1)];
end
T(17) = getPowerDeriv(y(4)+params(5)*(y(6)-y(6)*(1-params(2))),params(6),1);
T(18) = T(2)*1/(1-params(7))*getPowerDeriv(y(7)/(1-params(7)),1-params(7),1);
T(19) = getPowerDeriv(T(4),1-params(8),1);
T(20) = getPowerDeriv(T(5),1/(1-params(8)),1);
T(21) = getPowerDeriv(T(4)/y(12),1-params(8),1);
T(22) = T(3)*1/params(7)*getPowerDeriv(y(8)/params(7),params(7),1);
end
