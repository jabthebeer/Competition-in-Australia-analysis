%
% Status : main Dynare file
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

tic0 = tic;
% Define global variables.
global M_ options_ oo_ estim_params_ bayestopt_ dataset_ dataset_info estimation_info
options_ = [];
M_.fname = 'transition';
M_.dynare_version = '6.1';
oo_.dynare_version = '6.1';
options_.dynare_version = '6.1';
%
% Some global variables initialization
%
global_initialization;
M_.exo_names = {};
M_.exo_names_tex = {};
M_.exo_names_long = {};
M_.endo_names = cell(13,1);
M_.endo_names_tex = cell(13,1);
M_.endo_names_long = cell(13,1);
M_.endo_names(1) = {'Yt'};
M_.endo_names_tex(1) = {'Yt'};
M_.endo_names_long(1) = {'Yt'};
M_.endo_names(2) = {'Ct'};
M_.endo_names_tex(2) = {'Ct'};
M_.endo_names_long(2) = {'Ct'};
M_.endo_names(3) = {'Bt'};
M_.endo_names_tex(3) = {'Bt'};
M_.endo_names_long(3) = {'Bt'};
M_.endo_names(4) = {'Lpt'};
M_.endo_names_tex(4) = {'Lpt'};
M_.endo_names_long(4) = {'Lpt'};
M_.endo_names(5) = {'Kt'};
M_.endo_names_tex(5) = {'Kt'};
M_.endo_names_long(5) = {'Kt'};
M_.endo_names(6) = {'Nt'};
M_.endo_names_tex(6) = {'Nt'};
M_.endo_names_long(6) = {'Nt'};
M_.endo_names(7) = {'Wt'};
M_.endo_names_tex(7) = {'Wt'};
M_.endo_names_long(7) = {'Wt'};
M_.endo_names(8) = {'Rt'};
M_.endo_names_tex(8) = {'Rt'};
M_.endo_names_long(8) = {'Rt'};
M_.endo_names(9) = {'Qt'};
M_.endo_names_tex(9) = {'Qt'};
M_.endo_names_long(9) = {'Qt'};
M_.endo_names(10) = {'Zt'};
M_.endo_names_tex(10) = {'Zt'};
M_.endo_names_long(10) = {'Zt'};
M_.endo_names(11) = {'Gt'};
M_.endo_names_tex(11) = {'Gt'};
M_.endo_names_long(11) = {'Gt'};
M_.endo_names(12) = {'Ot'};
M_.endo_names_tex(12) = {'Ot'};
M_.endo_names_long(12) = {'Ot'};
M_.endo_names(13) = {'Mut'};
M_.endo_names_tex(13) = {'Mut'};
M_.endo_names_long(13) = {'Mut'};
M_.endo_partitions = struct();
M_.param_names = cell(9,1);
M_.param_names_tex = cell(9,1);
M_.param_names_long = cell(9,1);
M_.param_names(1) = {'beta'};
M_.param_names_tex(1) = {'beta'};
M_.param_names_long(1) = {'beta'};
M_.param_names(2) = {'varphi'};
M_.param_names_tex(2) = {'varphi'};
M_.param_names_long(2) = {'varphi'};
M_.param_names(3) = {'delta'};
M_.param_names_tex(3) = {'delta'};
M_.param_names_long(3) = {'delta'};
M_.param_names(4) = {'psi'};
M_.param_names_tex(4) = {'psi'};
M_.param_names_long(4) = {'psi'};
M_.param_names(5) = {'F'};
M_.param_names_tex(5) = {'F'};
M_.param_names_long(5) = {'F'};
M_.param_names(6) = {'nu'};
M_.param_names_tex(6) = {'nu'};
M_.param_names_long(6) = {'nu'};
M_.param_names(7) = {'alpha'};
M_.param_names_tex(7) = {'alpha'};
M_.param_names_long(7) = {'alpha'};
M_.param_names(8) = {'theta'};
M_.param_names_tex(8) = {'theta'};
M_.param_names_long(8) = {'theta'};
M_.param_names(9) = {'phi'};
M_.param_names_tex(9) = {'phi'};
M_.param_names_long(9) = {'phi'};
M_.param_partitions = struct();
M_.exo_det_nbr = 0;
M_.exo_nbr = 0;
M_.endo_nbr = 13;
M_.param_nbr = 9;
M_.orig_endo_nbr = 13;
M_.aux_vars = [];
M_.Sigma_e = zeros(0, 0);
M_.Correlation_matrix = eye(0, 0);
M_.H = 0;
M_.Correlation_matrix_ME = 1;
M_.sigma_e_is_diagonal = true;
M_.det_shocks = [];
M_.surprise_shocks = [];
M_.learnt_shocks = [];
M_.learnt_endval = [];
M_.heteroskedastic_shocks.Qvalue_orig = [];
M_.heteroskedastic_shocks.Qscale_orig = [];
M_.matched_irfs = {};
M_.matched_irfs_weights = {};
options_.linear = false;
options_.block = false;
options_.bytecode = false;
options_.use_dll = false;
options_.ramsey_policy = false;
options_.discretionary_policy = false;
M_.eq_nbr = 13;
M_.ramsey_orig_eq_nbr = 0;
M_.ramsey_orig_endo_nbr = 0;
M_.set_auxiliary_variables = exist(['./+' M_.fname '/set_auxiliary_variables.m'], 'file') == 2;
M_.epilogue_names = {};
M_.epilogue_var_list_ = {};
M_.orig_maximum_endo_lag = 1;
M_.orig_maximum_endo_lead = 1;
M_.orig_maximum_exo_lag = 0;
M_.orig_maximum_exo_lead = 0;
M_.orig_maximum_exo_det_lag = 0;
M_.orig_maximum_exo_det_lead = 0;
M_.orig_maximum_lag = 1;
M_.orig_maximum_lead = 1;
M_.orig_maximum_lag_with_diffs_expanded = 1;
M_.lead_lag_incidence = [
 0 3 0;
 0 4 16;
 0 5 0;
 0 6 0;
 1 7 0;
 2 8 0;
 0 9 0;
 0 10 17;
 0 11 18;
 0 12 0;
 0 13 0;
 0 14 0;
 0 15 0;]';
M_.nstatic = 8;
M_.nfwrd   = 3;
M_.npred   = 2;
M_.nboth   = 0;
M_.nsfwrd   = 3;
M_.nspred   = 2;
M_.ndynamic   = 5;
M_.dynamic_tmp_nbr = [16; 6; 0; 0; ];
M_.equations_tags = {
  1 , 'name' , '1' ;
  2 , 'name' , '2' ;
  3 , 'name' , 'Qt' ;
  4 , 'name' , 'Wt' ;
  5 , 'name' , 'Ot' ;
  6 , 'name' , 'Yt' ;
  7 , 'name' , '7' ;
  8 , 'name' , 'Rt' ;
  9 , 'name' , '9' ;
  10 , 'name' , 'Zt' ;
  11 , 'name' , 'Gt' ;
  12 , 'name' , 'Mut' ;
  13 , 'name' , '13' ;
};
M_.mapping.Yt.eqidx = [3 6 7 8 9 ];
M_.mapping.Ct.eqidx = [1 2 3 4 6 ];
M_.mapping.Bt.eqidx = [6 9 ];
M_.mapping.Lpt.eqidx = [4 7 ];
M_.mapping.Kt.eqidx = [6 8 ];
M_.mapping.Nt.eqidx = [3 4 10 11 12 ];
M_.mapping.Wt.eqidx = [2 4 5 7 8 ];
M_.mapping.Rt.eqidx = [1 5 7 8 ];
M_.mapping.Qt.eqidx = [2 3 ];
M_.mapping.Zt.eqidx = [10 13 ];
M_.mapping.Gt.eqidx = [3 11 ];
M_.mapping.Ot.eqidx = [5 7 8 9 13 ];
M_.mapping.Mut.eqidx = [7 8 9 12 13 ];
M_.static_and_dynamic_models_differ = false;
M_.has_external_function = true;
M_.block_structure.time_recursive = false;
M_.block_structure.block(1).Simulation_Type = 8;
M_.block_structure.block(1).endo_nbr = 13;
M_.block_structure.block(1).mfs = 12;
M_.block_structure.block(1).equation = [ 13 2 7 8 9 10 11 12 4 6 1 3 5];
M_.block_structure.block(1).variable = [ 12 7 4 1 3 10 11 13 6 5 2 9 8];
M_.block_structure.block(1).is_linear = false;
M_.block_structure.block(1).NNZDerivatives = 54;
M_.block_structure.block(1).bytecode_jacob_cols_to_sparse = [8 9 0 13 14 15 16 17 18 19 20 21 22 23 24 34 35 36 ];
M_.block_structure.block(1).g1_sparse_rowval = int32([5 6 7 8 11 3 9 1 2 3 8 12 2 8 2 3 4 9 11 4 9 2 3 4 5 12 6 11 2 3 4 7 12 8 9 1 8 9 10 11 11 2 3 12 1 10 11 1 11 10 ]);
M_.block_structure.block(1).g1_sparse_colval = int32([8 8 8 8 8 9 9 13 13 13 13 13 14 14 15 15 15 15 15 16 16 17 17 17 17 17 18 18 19 19 19 19 19 20 21 22 22 22 22 22 23 24 24 24 34 34 34 35 35 36 ]);
M_.block_structure.block(1).g1_sparse_colptr = int32([1 1 1 1 1 1 1 1 6 8 8 8 8 13 15 20 22 27 29 34 35 36 41 42 45 45 45 45 45 45 45 45 45 45 48 50 51 ]);
M_.block_structure.variable_reordered = [ 12 7 4 1 3 10 11 13 6 5 2 9 8];
M_.block_structure.equation_reordered = [ 13 2 7 8 9 10 11 12 4 6 1 3 5];
M_.block_structure.incidence(1).lead_lag = -1;
M_.block_structure.incidence(1).sparse_IM = [
 3 6;
 4 6;
 6 5;
 8 5;
 10 6;
 11 6;
 12 6;
];
M_.block_structure.incidence(2).lead_lag = 0;
M_.block_structure.incidence(2).sparse_IM = [
 1 2;
 2 2;
 2 7;
 3 1;
 3 2;
 3 9;
 3 11;
 4 2;
 4 4;
 4 6;
 4 7;
 5 7;
 5 8;
 5 12;
 6 1;
 6 2;
 6 3;
 6 5;
 7 1;
 7 4;
 7 7;
 7 8;
 7 12;
 7 13;
 8 1;
 8 7;
 8 8;
 8 12;
 8 13;
 9 1;
 9 3;
 9 12;
 9 13;
 10 10;
 11 11;
 12 13;
 13 10;
 13 12;
 13 13;
];
M_.block_structure.incidence(3).lead_lag = 1;
M_.block_structure.incidence(3).sparse_IM = [
 1 2;
 1 8;
 2 2;
 2 9;
 3 2;
 3 9;
];
M_.block_structure.dyn_tmp_nbr = 23;
M_.state_var = [6 5 ];
M_.maximum_lag = 1;
M_.maximum_lead = 1;
M_.maximum_endo_lag = 1;
M_.maximum_endo_lead = 1;
oo_.steady_state = zeros(13, 1);
M_.maximum_exo_lag = 0;
M_.maximum_exo_lead = 0;
oo_.exo_steady_state = zeros(0, 1);
M_.params = NaN(9, 1);
M_.endo_trends = struct('deflator', cell(13, 1), 'log_deflator', cell(13, 1), 'growth_factor', cell(13, 1), 'log_growth_factor', cell(13, 1));
M_.NNZDerivatives = [52; -1; -1; ];
M_.dynamic_g1_sparse_rowval = int32([6 8 3 4 10 11 12 3 6 7 8 9 1 2 3 4 6 6 9 4 7 6 4 2 4 5 7 8 5 7 8 3 10 13 3 11 5 7 8 9 13 7 8 9 12 13 1 2 3 1 2 3 ]);
M_.dynamic_g1_sparse_colval = int32([5 5 6 6 6 6 6 14 14 14 14 14 15 15 15 15 15 16 16 17 17 18 19 20 20 20 20 20 21 21 21 22 23 23 24 24 25 25 25 25 25 26 26 26 26 26 28 28 28 34 35 35 ]);
M_.dynamic_g1_sparse_colptr = int32([1 1 1 1 1 3 8 8 8 8 8 8 8 8 13 18 20 22 23 24 29 32 33 35 37 42 47 47 50 50 50 50 50 50 51 53 53 53 53 53 ]);
M_.lhs = {
'1'; 
'F*Wt'; 
'Qt'; 
'Wt'; 
'Ot'; 
'Yt'; 
'Wt'; 
'Rt'; 
'1'; 
'Zt'; 
'Gt'; 
'Mut'; 
'Ot'; 
};
M_.static_tmp_nbr = [16; 6; 0; 0; ];
M_.block_structure_stat.block(1).Simulation_Type = 3;
M_.block_structure_stat.block(1).endo_nbr = 1;
M_.block_structure_stat.block(1).mfs = 1;
M_.block_structure_stat.block(1).equation = [ 1];
M_.block_structure_stat.block(1).variable = [ 8];
M_.block_structure_stat.block(2).Simulation_Type = 6;
M_.block_structure_stat.block(2).endo_nbr = 12;
M_.block_structure_stat.block(2).mfs = 12;
M_.block_structure_stat.block(2).equation = [ 2 3 4 5 6 7 8 9 10 11 12 13];
M_.block_structure_stat.block(2).variable = [ 9 1 4 7 2 12 5 3 10 11 6 13];
M_.block_structure_stat.variable_reordered = [ 8 9 1 4 7 2 12 5 3 10 11 6 13];
M_.block_structure_stat.equation_reordered = [ 1 2 3 4 5 6 7 8 9 10 11 12 13];
M_.block_structure_stat.incidence.sparse_IM = [
 1 8;
 2 7;
 2 9;
 3 1;
 3 6;
 3 9;
 3 11;
 4 2;
 4 4;
 4 6;
 4 7;
 5 7;
 5 8;
 5 12;
 6 1;
 6 2;
 6 3;
 6 5;
 7 1;
 7 4;
 7 7;
 7 8;
 7 12;
 7 13;
 8 1;
 8 5;
 8 7;
 8 8;
 8 12;
 8 13;
 9 1;
 9 3;
 9 12;
 9 13;
 10 6;
 10 10;
 11 6;
 11 11;
 12 6;
 12 13;
 13 10;
 13 12;
 13 13;
];
M_.block_structure_stat.tmp_nbr = 16;
M_.block_structure_stat.block(1).g1_sparse_rowval = int32([1 ]);
M_.block_structure_stat.block(1).g1_sparse_colval = int32([1 ]);
M_.block_structure_stat.block(1).g1_sparse_colptr = int32([1 2 ]);
M_.block_structure_stat.block(2).g1_sparse_rowval = int32([1 2 2 5 6 7 8 3 6 1 3 4 6 7 3 5 4 6 7 8 12 5 7 5 8 9 12 2 10 2 3 9 10 11 6 7 8 11 12 ]);
M_.block_structure_stat.block(2).g1_sparse_colval = int32([1 1 2 2 2 2 2 3 3 4 4 4 4 4 5 5 6 6 6 6 6 7 7 8 8 9 9 10 10 11 11 11 11 11 12 12 12 12 12 ]);
M_.block_structure_stat.block(2).g1_sparse_colptr = int32([1 3 8 10 15 17 22 24 26 28 30 35 40 ]);
M_.static_g1_sparse_rowval = int32([3 6 7 8 9 4 6 6 9 4 7 6 8 3 4 10 11 12 2 4 5 7 8 1 5 7 8 2 3 10 13 3 11 5 7 8 9 13 7 8 9 12 13 ]);
M_.static_g1_sparse_colval = int32([1 1 1 1 1 2 2 3 3 4 4 5 5 6 6 6 6 6 7 7 7 7 7 8 8 8 8 9 9 10 10 11 11 12 12 12 12 12 13 13 13 13 13 ]);
M_.static_g1_sparse_colptr = int32([1 6 8 10 12 14 19 24 28 30 32 34 39 44 ]);
load xpar;
M_.params(1) = xpar(1);
beta = M_.params(1);
M_.params(2) = xpar(2);
varphi = M_.params(2);
M_.params(3) = xpar(3);
delta = M_.params(3);
M_.params(4) = xpar(4);
psi = M_.params(4);
M_.params(5) = xpar(5);
F = M_.params(5);
M_.params(6) = xpar(6);
nu = M_.params(6);
M_.params(7) = xpar(7);
alpha = M_.params(7);
M_.params(8) = xpar(8);
theta = M_.params(8);
M_.params(9) = xpar(9);
phi = M_.params(9);
load x1_ss;
load x2_ss;
%
% INITVAL instructions
%
options_.initval_file = false;
oo_.steady_state(5) = x1_ss(1);
oo_.steady_state(6) = x1_ss(2);
if M_.exo_nbr > 0
	oo_.exo_simul = ones(M_.maximum_lag,1)*oo_.exo_steady_state';
end
if M_.exo_det_nbr > 0
	oo_.exo_det_simul = ones(M_.maximum_lag,1)*oo_.exo_det_steady_state';
end
%
% ENDVAL instructions
%
oo_.initial_steady_state = oo_.steady_state;
oo_.initial_exo_steady_state = oo_.exo_steady_state;
oo_.steady_state(1) = x2_ss(1);
oo_.steady_state(2) = x2_ss(2);
oo_.steady_state(3) = x2_ss(3);
oo_.steady_state(4) = x2_ss(4);
oo_.steady_state(5) = x2_ss(5);
oo_.steady_state(6) = x2_ss(6);
oo_.steady_state(7) = x2_ss(7);
oo_.steady_state(8) = x2_ss(8);
oo_.steady_state(9) = x2_ss(9);
oo_.steady_state(10) = x2_ss(10);
oo_.steady_state(11) = x2_ss(11);
oo_.steady_state(12) = x2_ss(12);
oo_.steady_state(13) = x2_ss(13);
options_resid_ = struct();
display_static_residuals(M_, options_, oo_, options_resid_);
steady;
options_.periods = 500;
oo_ = perfect_foresight_setup(M_, options_, oo_);
options_.dynatol.f = 1e-10;
options_.dynatol.x = 1e-10;
[oo_, Simulated_time_series] = perfect_foresight_solver(M_, options_, oo_);


oo_.time = toc(tic0);
disp(['Total computing time : ' dynsec2hms(oo_.time) ]);
if ~exist([M_.dname filesep 'Output'],'dir')
    mkdir(M_.dname,'Output');
end
save([M_.dname filesep 'Output' filesep 'transition_results.mat'], 'oo_', 'M_', 'options_');
if exist('estim_params_', 'var') == 1
  save([M_.dname filesep 'Output' filesep 'transition_results.mat'], 'estim_params_', '-append');
end
if exist('bayestopt_', 'var') == 1
  save([M_.dname filesep 'Output' filesep 'transition_results.mat'], 'bayestopt_', '-append');
end
if exist('dataset_', 'var') == 1
  save([M_.dname filesep 'Output' filesep 'transition_results.mat'], 'dataset_', '-append');
end
if exist('estimation_info', 'var') == 1
  save([M_.dname filesep 'Output' filesep 'transition_results.mat'], 'estimation_info', '-append');
end
if exist('dataset_info', 'var') == 1
  save([M_.dname filesep 'Output' filesep 'transition_results.mat'], 'dataset_info', '-append');
end
if exist('oo_recursive_', 'var') == 1
  save([M_.dname filesep 'Output' filesep 'transition_results.mat'], 'oo_recursive_', '-append');
end
if exist('options_mom_', 'var') == 1
  save([M_.dname filesep 'Output' filesep 'transition_results.mat'], 'options_mom_', '-append');
end
if ~isempty(lastwarn)
  disp('Note: warning(s) encountered in MATLAB/Octave code')
end
