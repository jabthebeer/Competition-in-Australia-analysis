***************************************
***** Code to take superlasticities and summarise
***** From Hambur and Freestone 2025 - How Costly are Markups in Australia
** Takes markup estiamtes from other work, as noted in readme files
**************************************


local outputs ""

** Loop over trims
*foreach trim in iy iy_w iy95  iy95_w {
	foreach trim in  iy_w  iy95_w {

	** loop over mus
	foreach mu in m_DLW_tl_m_w_y markup_w_y  {
	*foreach mu in m_DLW_tl_m_w_y   {

global mu `mu'		
** Use aggregate estimates, natioanl level outputs
		use "`outputs'\agg_pass_trim_`trim'_`mu'_2024.dta"  , clear  
		** remove outlliers
		drop if s_elast_fe<-1
		egen mu99 =pctile( wy_ ) , p(99)
		drop if wy_ > mu99 
		** tot share for construct max sahres
		bysort fyear: egen Y_tot = sum(Y_nom)
		g ind_w = Y_nom/Y_tot
		
		replace hwy_$mu = 1/hwy_$mu
		
		** max stats for checking outputs
		g coav_fe = cov_fe/sigma_w
		foreach var in max_sigma_w max_rho_nfe_w max_rho_fe_w max_sig_rho_nfe_w max_sig_rho_fe_w max_wy_$mu  max_wm_$mu  {
			local temp=substr("`var'", 5,.)
			g max_`var'_tot_sh = (`var'*ind_w)/`temp'
			drop `var'
		}
		
			foreach var in  max_Y_share max_M_share max_labour_share {
			g max_`var'_tot_sh = `var'*ind_w
			drop `var'
		}
		**collapse
		collapse(mean) s_elast_nfe s_elast_fe sigma_w rho_nfe_w rho_fe_w cov_nfe cov_fe wy_$mu hwy_$mu wm_$mu coav_fe (p1) p1_s_elast_nfe=s_elast_nfe p1_s_elast_fe=s_elast_fe p1_sigma_w=sigma_w p1_rho_nfe_w=rho_nfe_w p1_rho_fe_w=rho_fe_w p1_cov_nfe=cov_nfe p1_cov_fe=cov_fe p1_coav_fe=coav_fe  (p25) p25_s_elast_nfe=s_elast_nfe p25_s_elast_fe=s_elast_fe p25_sigma_w=sigma_w p25_rho_nfe_w=rho_nfe_w p25_rho_fe_w=rho_fe_w p25_cov_nfe=cov_nfe p25_cov_fe=cov_fe p25_coav_fe=coav_fe (p50) p50_s_elast_nfe=s_elast_nfe p50_s_elast_fe=s_elast_fe p50_sigma_w=sigma_w p50_rho_nfe_w=rho_nfe_w p50_rho_fe_w=rho_fe_w p50_cov_nfe=cov_nfe p50_cov_fe=cov_fe p50_coav_fe=coav_fe (p75) p75_s_elast_nfe=s_elast_nfe p75_s_elast_fe=s_elast_fe p75_sigma_w=sigma_w p75_rho_nfe_w=rho_nfe_w p75_rho_fe_w=rho_fe_w p75_cov_nfe=cov_nfe p75_cov_fe=cov_fe p75_coav_fe=coav_fe (p99) p99_s_elast_nfe=s_elast_nfe p99_s_elast_fe=s_elast_fe p99_sigma_w=sigma_w p99_rho_nfe_w=rho_nfe_w p99_rho_fe_w=rho_fe_w p99_cov_nfe=cov_nfe p99_cov_fe=cov_fe p99_coav_fe=coav_fe (max) max_* (rawsum) firms=firmid [aweight = Y_nom], by(fyear)
		
				replace hwy_$mu = 1/hwy_$mu

				
		export excel using "`outputs'\super_sum_2024.xls", sheet("`mu'_`trim'_a") sheetreplace firstrow(variables)
** Use aggregate estiamtes, div level outputs
		
		use "`outputs'\agg_pass_trim_`trim'_`mu'_2024.dta"  , clear  
				drop if s_elast_fe<-1
		egen mu99 =pctile( wy_ ) , p(99)
		drop if wy_ > mu99 
		g division = "A" if industry < 600
replace division = "B" if industry > 599 & industry < 1100
replace division = "C" if industry > 1099 & industry < 2600
replace division = "D" if industry > 2599 & industry < 3000
replace division = "E" if industry > 2999 & industry < 3300
replace division = "F" if industry > 3299 & industry < 3900
replace division = "G" if industry > 3899 & industry < 4400
replace division = "H" if industry > 4399 & industry < 4600
replace division = "I" if industry > 4599 & industry < 5400
replace division = "J" if industry > 5399 & industry < 6200
replace division = "K" if industry > 6199 & industry < 6500
replace division = "L" if industry > 6599 & industry < 6800
replace division = "M" if industry > 6799 & industry < 7100
replace division = "N" if industry > 7199 & industry < 7400
replace division = "O" if industry > 7499 & industry < 8000
replace division = "P" if industry > 7999 & industry < 8300
replace division = "Q" if industry > 8399 & industry < 8800
replace division = "R" if industry > 8899 & industry < 9300
replace division = "S" if industry > 9399 & industry < 9999

		
		bysort fyear division: egen Y_tot = sum(Y_nom)
		g ind_w = Y_nom/Y_tot
		
	foreach var in max_sigma_w max_rho_nfe_w max_rho_fe_w max_sig_rho_nfe_w max_sig_rho_fe_w max_wy_$mu max_wm_$mu  {
			local temp=substr("`var'", 5,.)
			g max_`var'_tot_sh = (`var'*ind_w)/`temp'
			drop `var'
		}
				g coav_fe = cov_fe/sigma_w

			foreach var in  max_Y_share max_M_share max_labour_share {
			g max_`var'_tot_sh = `var'*ind_w
			drop `var'
		}
		
						replace hwy_$mu = 1/hwy_$mu

		collapse(mean) s_elast_nfe s_elast_fe sigma_w rho_nfe_w rho_fe_w cov_nfe cov_fe wy_$mu wm_$mu hwy_$mu  coav_fe (p50) p50_s_elast_nfe=s_elast_nfe p50_s_elast_fe=s_elast_fe p50_sigma_w=sigma_w p50_rho_nfe_w=rho_nfe_w p50_rho_fe_w=rho_fe_w p50_cov_nfe=cov_nfe p50_cov_fe=cov_fe  p50_coav_fe=coav_fe (max) max_* (rawsum) firms=firmid [aweight = Y_nom], by(fyear division)
		
						replace hwy_$mu = 1/hwy_$mu

ds max_*			
foreach var in `r(varlist)' {
	drop if `var'>0.33
		}	
		export excel using "`outputs'\super_sum_2024.xls", sheet("`mu'_`trim'_a_d") sheetreplace firstrow(variables)
		
		
		
		
** Use div estiamtes, aggr level outputs
		use "`outputs'\div_pass_trim_`trim'_`mu'_2024.dta"  , clear  
				drop if s_elast_fe<-1
		egen mu99 =pctile( wy_ ) , p(99)
		drop if wy_ > mu99 
		** tot share for construct max sahres
		bysort fyear: egen Y_tot = sum(Y_nom)
		g ind_w = Y_nom/Y_tot
		
foreach var in max_sigma_w max_rho_nfe_w max_rho_fe_w max_sig_rho_nfe_w max_sig_rho_fe_w max_wy_$mu   max_wm_$mu  {
			local temp=substr("`var'", 5,.)
			g max_`var'_tot_sh = (`var'*ind_w)/`temp'
			drop `var'
		}
				g coav_fe = cov_fe/sigma_w

			foreach var in  max_Y_share max_M_share max_labour_share {
			g max_`var'_tot_sh = `var'*ind_w
			drop `var'
		}
		
						replace hwy_$mu = 1/hwy_$mu

		**collapse
		collapse(mean) s_elast_nfe s_elast_fe sigma_w rho_nfe_w rho_fe_w cov_nfe cov_fe wy_$mu hwy_$mu wm_$mu coav_fe (p1) p1_s_elast_nfe=s_elast_nfe p1_s_elast_fe=s_elast_fe p1_sigma_w=sigma_w p1_rho_nfe_w=rho_nfe_w p1_rho_fe_w=rho_fe_w p1_cov_nfe=cov_nfe p1_cov_fe=cov_fe p1_coav_fe=coav_fe  (p25) p25_s_elast_nfe=s_elast_nfe p25_s_elast_fe=s_elast_fe p25_sigma_w=sigma_w p25_rho_nfe_w=rho_nfe_w p25_rho_fe_w=rho_fe_w p25_cov_nfe=cov_nfe p25_cov_fe=cov_fe p25_coav_fe=coav_fe (p50) p50_s_elast_nfe=s_elast_nfe p50_s_elast_fe=s_elast_fe p50_sigma_w=sigma_w p50_rho_nfe_w=rho_nfe_w p50_rho_fe_w=rho_fe_w p50_cov_nfe=cov_nfe p50_cov_fe=cov_fe p50_coav_fe=coav_fe (p75) p75_s_elast_nfe=s_elast_nfe p75_s_elast_fe=s_elast_fe p75_sigma_w=sigma_w p75_rho_nfe_w=rho_nfe_w p75_rho_fe_w=rho_fe_w p75_cov_nfe=cov_nfe p75_cov_fe=cov_fe p75_coav_fe=coav_fe (p99) p99_s_elast_nfe=s_elast_nfe p99_s_elast_fe=s_elast_fe p99_sigma_w=sigma_w p99_rho_nfe_w=rho_nfe_w p99_rho_fe_w=rho_fe_w p99_cov_nfe=cov_nfe p99_cov_fe=cov_fe p99_coav_fe=coav_fe (max) max_* (rawsum) firms=firmid [aweight = Y_nom], by(fyear)
		
		
						replace hwy_$mu = 1/hwy_$mu

		export excel using "`outputs'\super_sum_2024.xls", sheet("`mu'_`trim'_d") sheetreplace firstrow(variables)
** Use div estiamtes, div level outputs
		
		use "`outputs'\div_pass_trim_`trim'_`mu'_2024.dta"  , clear  
				drop if s_elast_fe<-1
		egen mu99 =pctile( wy_ ) , p(99)
		drop if wy_ > mu99 
		g division = "A" if industry < 600
replace division = "B" if industry > 599 & industry < 1100
replace division = "C" if industry > 1099 & industry < 2600
replace division = "D" if industry > 2599 & industry < 3000
replace division = "E" if industry > 2999 & industry < 3300
replace division = "F" if industry > 3299 & industry < 3900
replace division = "G" if industry > 3899 & industry < 4400
replace division = "H" if industry > 4399 & industry < 4600
replace division = "I" if industry > 4599 & industry < 5400
replace division = "J" if industry > 5399 & industry < 6200
replace division = "K" if industry > 6199 & industry < 6500
replace division = "L" if industry > 6599 & industry < 6800
replace division = "M" if industry > 6799 & industry < 7100
replace division = "N" if industry > 7199 & industry < 7400
replace division = "O" if industry > 7499 & industry < 8000
replace division = "P" if industry > 7999 & industry < 8300
replace division = "Q" if industry > 8399 & industry < 8800
replace division = "R" if industry > 8899 & industry < 9300
replace division = "S" if industry > 9399 & industry < 9999

		
		bysort fyear division: egen Y_tot = sum(Y_nom)
		g ind_w = Y_nom/Y_tot
		
foreach var in max_sigma_w max_rho_nfe_w max_rho_fe_w max_sig_rho_nfe_w max_sig_rho_fe_w max_wy_$mu   max_wm_$mu  {
			local temp=substr("`var'", 5,.)
			g max_`var'_tot_sh = (`var'*ind_w)/`temp'
			drop `var'
		}
				g coav_fe = cov_fe/sigma_w

			foreach var in  max_Y_share max_M_share max_labour_share {
			g max_`var'_tot_sh = `var'*ind_w
			drop `var'
		}
		
								replace hwy_$mu = 1/hwy_$mu

		
		collapse(mean) s_elast_nfe s_elast_fe sigma_w rho_nfe_w rho_fe_w cov_nfe cov_fe wy_$mu wm_$mu hwy_$mu coav_fe (p50) p50_s_elast_nfe=s_elast_nfe p50_s_elast_fe=s_elast_fe p50_sigma_w=sigma_w p50_rho_nfe_w=rho_nfe_w p50_rho_fe_w=rho_fe_w p50_cov_nfe=cov_nfe p50_cov_fe=cov_fe  p50_coav_fe=coav_fe (max) max_max_* (rawsum) firms=firmid [aweight = Y_nom], by(fyear division)
							replace hwy_$mu = 1/hwy_$mu

		
ds max_*			
foreach var in `r(varlist)' {
	drop if `var'>0.33
		}	
		export excel using "`outputs'\super_sum_2024.xls", sheet("`mu'_`trim'_d_d") sheetreplace firstrow(variables)
	
	
		
** Use industry estiamtes (preffered), aggregate level outputs
		use "`outputs'\pass_trim_`trim'_`mu'_2024.dta"  , clear  
drop if s_elast_fe<-1
		egen mu99 =pctile( wy_ ) , p(99)
		drop if wy_ > mu99 
		** tot share for construct max sahres
		bysort fyear: egen Y_tot = sum(Y_nom)
		g ind_w = Y_nom/Y_tot
				g coav_fe = cov_fe/sigma_w

		foreach var in max_sigma_w max_rho_nfe_w max_rho_fe_w max_sig_rho_nfe_w max_sig_rho_fe_w max_wy_$mu   max_wm_$mu max_Y_share max_M_share {
			g max_`var'_tot_sh = `var'*ind_w
			drop `var'
		}
		
								replace hwy_$mu = 1/hwy_$mu

		**collapse
		collapse(mean) s_elast_nfe s_elast_fe sigma_w rho_nfe_w rho_fe_w cov_nfe cov_fe wy_$mu hwy_$mu wm_$mu coav_fe (p1) p1_s_elast_nfe=s_elast_nfe p1_s_elast_fe=s_elast_fe p1_sigma_w=sigma_w p1_rho_nfe_w=rho_nfe_w p1_rho_fe_w=rho_fe_w p1_cov_nfe=cov_nfe p1_cov_fe=cov_fe p1_coav_fe=coav_fe  (p25) p25_s_elast_nfe=s_elast_nfe p25_s_elast_fe=s_elast_fe p25_sigma_w=sigma_w p25_rho_nfe_w=rho_nfe_w p25_rho_fe_w=rho_fe_w p25_cov_nfe=cov_nfe p25_cov_fe=cov_fe p25_coav_fe=coav_fe (p50) p50_s_elast_nfe=s_elast_nfe p50_s_elast_fe=s_elast_fe p50_sigma_w=sigma_w p50_rho_nfe_w=rho_nfe_w p50_rho_fe_w=rho_fe_w p50_cov_nfe=cov_nfe p50_cov_fe=cov_fe p50_coav_fe=coav_fe (p75) p75_s_elast_nfe=s_elast_nfe p75_s_elast_fe=s_elast_fe p75_sigma_w=sigma_w p75_rho_nfe_w=rho_nfe_w p75_rho_fe_w=rho_fe_w p75_cov_nfe=cov_nfe p75_cov_fe=cov_fe p75_coav_fe=coav_fe (p99) p99_s_elast_nfe=s_elast_nfe p99_s_elast_fe=s_elast_fe p99_sigma_w=sigma_w p99_rho_nfe_w=rho_nfe_w p99_rho_fe_w=rho_fe_w p99_cov_nfe=cov_nfe p99_cov_fe=cov_fe p99_coav_fe=coav_fe (max) max_* (rawsum) firms=firmid [aweight = Y_nom], by(fyear)
		
		
								replace hwy_$mu = 1/hwy_$mu

		export excel using "`outputs'\super_sum_2024.xls", sheet("`mu'_`trim'_i") sheetreplace firstrow(variables)
** Use industry estiamtes (preffered), div level outputs
		
		use "`outputs'\pass_trim_`trim'_`mu'_2024.dta"  , clear  
				drop if s_elast_fe<-1
						egen mu99 =pctile( wy_ ) , p(99)
		drop if wy_ > mu99 
		** tot share for construct max sahres
		bysort fyear: egen Y_tot = sum(Y_nom)
		g ind_w = Y_nom/Y_tot

		g division = "A" if industry < 600
replace division = "B" if industry > 599 & industry < 1100
replace division = "C" if industry > 1099 & industry < 2600
replace division = "D" if industry > 2599 & industry < 3000
replace division = "E" if industry > 2999 & industry < 3300
replace division = "F" if industry > 3299 & industry < 3900
replace division = "G" if industry > 3899 & industry < 4400
replace division = "H" if industry > 4399 & industry < 4600
replace division = "I" if industry > 4599 & industry < 5400
replace division = "J" if industry > 5399 & industry < 6200
replace division = "K" if industry > 6199 & industry < 6500
replace division = "L" if industry > 6599 & industry < 6800
replace division = "M" if industry > 6799 & industry < 7100
replace division = "N" if industry > 7199 & industry < 7400
replace division = "O" if industry > 7499 & industry < 8000
replace division = "P" if industry > 7999 & industry < 8300
replace division = "Q" if industry > 8399 & industry < 8800
replace division = "R" if industry > 8899 & industry < 9300
replace division = "S" if industry > 9399 & industry < 9999

		
				g coav_fe = cov_fe/sigma_w

		foreach var in max_sigma_w max_rho_nfe_w max_rho_fe_w max_sig_rho_nfe_w max_sig_rho_fe_w max_wy_$mu   max_wm_$mu max_Y_share max_M_share {
			g max_`var'_tot_sh = `var'*ind_w
			drop `var'
		}
		
								replace hwy_$mu = 1/hwy_$mu

		
		collapse(mean) s_elast_nfe s_elast_fe sigma_w rho_nfe_w rho_fe_w cov_nfe cov_fe wy_$mu wm_$mu hwy_$mu coav_fe (p50) p50_s_elast_nfe=s_elast_nfe p50_s_elast_fe=s_elast_fe p50_sigma_w=sigma_w p50_rho_nfe_w=rho_nfe_w p50_rho_fe_w=rho_fe_w p50_cov_nfe=cov_nfe p50_cov_fe=cov_fe  p50_coav_fe=coav_fe (max) max_* (rawsum) firms=firmid [aweight = Y_nom], by(fyear division)
		
		
								replace hwy_$mu = 1/hwy_$mu
								
								ds max_*			
foreach var in `r(varlist)' {
	drop if `var'>0.33
		}	

		export excel using "`outputs'\super_sum_2024.xls", sheet("`mu'_`trim'_i_d") sheetreplace firstrow(variables)		
	
	}
}



	