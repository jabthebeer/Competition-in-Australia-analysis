clear; 
clc;

format short g

Markuptarget = 1.05;                        % our target for aggregate markup

N            = 414.6473;                      % mean number of firms in sector
p.sigma      = 1.6220;
p.gamma      = 59.6930; 
p.xi         = 28.0803; 


% Markuptarget = 1.25;                         % our target for aggregate markup
% 
% N            = 143.24;                       % mean number of firms in sector
% p.sigma      = 1.1485;
% p.gamma      = 7.1573; 
% p.xi         = 5.1451; 

% Markuptarget = 1.30; 
% 
% 
% N            = 109.39;                     % mean number of firms in sector
% p.sigma      = 1.0664;
% p.gamma      = 5.9662; 
% p.xi         = 4.3576; 
% 
% 
% Markuptarget = 1.35;                       % our target for aggregate markup
% 
% N            = 112.44;                     % mean number of firms in sector
% p.sigma      = 0.99424;
% p.gamma      = 5.2127; 
% p.xi         = 3.7245; 


x            = [N;     p.sigma;   p.gamma;   p.xi];
 
lb           = [350;     1.1;       40.0;     20.0];  
ub           = [500;     2.1;       80.0;     40.0];

ftarget      = @(x) objective(x, Markuptarget);

 
% ftarget(x)
% return

 
switch 'fminsearch' 

    case 'fminsearch'
        
        disp('fminsearch')
        
        options             = optimset('fminsearch');
        options.Display     = 'iter';
        options.TolX        = 1e-4;
        options.MaxFunEvals = 250;

        x    = fminsearchbnd(ftarget, x, lb, ub, options);
   
    
    case 'ga'

        disp('ga')
        gaoptions = gaoptimset('Display', 'off','UseParallel', 'always', 'InitialPopulation', x');
        x         = ga(@(x)ftarget(x), size(x, 1), [], [], [], [], lb, ub, [], gaoptions); 

  
    case 'particleswarm'
       
       disp('particleswarm')

       options = optimoptions('particleswarm', 'Display', 'off', 'MaxTime',  10000, 'UseParallel', true, 'InitialSwarm', x',  'SwarmSize', 200);

       x   = particleswarm(ftarget, numel(x), lb', ub', options);   %this function complains  if I give it a structure as input
        
       
    case 'patternsearch'
        
       disp('patternsearch')

       options = optimoptions('patternsearch','Display','off', 'UseParallel', true);

       x  = patternsearch(ftarget, x, [], [], [], [], lb, ub, [], options);
       
      
end

x  = x(:);
