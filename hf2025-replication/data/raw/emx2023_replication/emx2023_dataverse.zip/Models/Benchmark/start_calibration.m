clear; 
clc;

format short g


Markuptarget = 1.05; 

p.xi         = 20.7021016669651;          % Pareto tail productivity
p.sigma      = 29.1008275310716;          % demand elasticity: match level of markups 


Markuptarget = 1.10;                      % our target for aggregate markup

p.xi         = 10.2987999947552;          % Pareto tail productivity
p.sigma      = 15.3992042842566;          % demand elasticity: match level of markups 


Markuptarget = 1.15; 

p.xi         =  6.8409724072258;          % Pareto tail productivity
p.sigma      = 10.8610835311753;          % demand elasticity: match level of markups 


Markuptarget = 1.20;                      % our target for aggregate markup

p.xi         = 5.10453727185321;          % Pareto tail productivity
p.sigma      = 8.56704900543676;          % demand elasticity: match level of markups 


Markuptarget = 1.25;                      % our target for aggregate markup

p.xi         = 4.06857848423202;          % Pareto tail productivity
p.sigma      = 7.2079290139342;           % demand elasticity: match level of markups 


Markuptarget = 1.30;                      % our target for aggregate markup

p.xi         = 3.37950775326023;          % Pareto tail productivity
p.sigma      = 6.30583163623233;          % demand elasticity: match level of markups 


Markuptarget = 1.35;                      % our target for aggregate markup

p.xi         = 2.88859963714985;          % Pareto tail productivity
p.sigma      = 5.66479780771211;          % demand elasticity: match level of markups 


x            = [p.xi;   p.sigma];
 
lb           = [2;       4];  
ub           = [4;       7];

ftarget      = @(x) objective(x, Markuptarget);



options             = optimset('fminsearch');
options.Display     = 'iter';
options.TolX        = 1e-5;
options.MaxFunEvals = 200;

x                   = fminsearchbnd(ftarget, x, lb, ub, options);
   
  